SYNTAX ANALYZER AND ERROR DETECTOR  (Compiler Design Mini Project)
===================================================================

HOW TO RUN
----------
1. Install Python 3 (https://www.python.org/downloads/).
   On Windows, tick "Add Python to PATH" during installation.
   Tkinter is included with Python (on Linux: sudo apt install python3-tk).
2. Unzip this folder.
3. Open a terminal / Command Prompt inside the folder and run:

       python main.py

   (If that fails, try:  python3 main.py   or   py main.py)

No extra libraries are needed.

HOW TO USE
----------
- Type or paste simple C code in the top box.
- Click "Analyze Code":
    * bottom-left box  = syntax errors / warnings (with line numbers)
    * bottom-right table = TOKENS found in the code (lexical analysis)
- Token types: KEYWORD, IDENTIFIER, NUMBER, STRING, CHARACTER,
  OPERATOR, SEPARATOR, PREPROCESSOR, UNKNOWN (invalid symbol such as @).
- Comments are not shown as tokens.
- Click "Clear" to empty both boxes.

SAMPLE 1 - Missing semicolon
----------------------------
int main() {
    int a = 10
    if (a > 5) {
        printf("Hello");
    }
}

Output:
Syntax Error:
Line 2: Missing semicolon after int a = 10

Analysis completed.

SAMPLE 2 - Missing assignment expression / incomplete statement
---------------------------------------------------------------
int main() {
    int a = ;
    a = 5 +;
    return 0;
}

Output:
Syntax Errors:
Line 2: Missing expression in assignment: int a =
Line 3: Incomplete statement: a = 5 +

Analysis completed.

SAMPLE 3 - Unmatched brackets
-----------------------------
int main() {
    int a[3;
    if (a[0] > 1 {
        printf("hi");
    }
}

Output:
Syntax Errors:
Line 2: Unmatched opening square bracket '[' (missing ']')
Line 3: Unmatched opening parenthesis '(' (missing ')')

Analysis completed.

SAMPLE 4 - Valid code (for-loop semicolons are NOT errors)
----------------------------------------------------------
#include <stdio.h>
int main() {
    int i;
    for (i = 0; i < 3; i++) {
        printf("%d", i);   // comment with ( { is ignored
    }
    return 0;
}

Output:
Success: No syntax errors detected.
(Only the supported checks were performed.)

Analysis completed.

SAMPLE 5 - Warning (not an error)
---------------------------------
int main() {
    int a = 1;
    if (a = 5) {
        a = 0;
    }
}

Output:
Success: No syntax errors detected.
(Only the supported checks were performed.)

Warning:
Line 3: Assignment '=' used inside condition (did you mean '=='?)

Analysis completed.

TOKEN TABLE EXAMPLE
-------------------
Input:   int a = 10;

Line  Token Type   Token
1     KEYWORD      int
1     IDENTIFIER   a
1     OPERATOR     =
1     NUMBER       10
1     SEPARATOR    ;
