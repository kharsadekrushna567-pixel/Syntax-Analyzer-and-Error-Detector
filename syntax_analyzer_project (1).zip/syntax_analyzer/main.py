"""
Syntax Analyzer and Error Detector  (Compiler Design Mini Project)
------------------------------------------------------------------
A small educational checker for simple C code, built with Python + Tkinter.

It is NOT a full C compiler. It only looks for these problems:
    * missing semicolons
    * unmatched (), {}, []
    * missing expressions in assignments  (int a = ;)
    * incomplete statements               (x = 5 + ;)
    * a few extra checks on if/while/for headers

It also shows the TOKENS of the code (lexical analysis): keywords,
identifiers, numbers, strings, operators and separators.

How it works (3 steps):
    1. CLEAN   - blank out comments, strings and #include lines
                 (so brackets/semicolons inside them are ignored).
    2. BRACKET - use a stack to match ( ) { } [ ].
    3. STATEMENT - split the code into statements and check each one.

Run with:   python main.py
"""

import re
import tkinter as tk
from tkinter import scrolledtext, ttk


# =====================================================================
#  PART 1 : ANALYZER LOGIC  (no GUI code in this part)
# =====================================================================

TYPE_WORDS = {"int", "float", "double", "char", "long", "short",
              "void", "unsigned", "signed"}

# Characters that mean "the expression is not finished yet" if they
# appear at the very end of a statement.
OPERATOR_END = set("+-*/%=&|^<>,!?.~(")

CONTROL_RE = re.compile(r"^(else\s+)?(if|while|for|switch)\b")
FOR_RE = re.compile(r"^(else\s+)?for\b")
ELSE_DO_RE = re.compile(r"^(else|do)\b")


# ---------- small helper functions ----------

def shorten(text, limit=50):
    """Collapse spaces and cut very long text so messages stay readable."""
    text = " ".join(text.split())
    if len(text) > limit:
        text = text[:limit - 3] + "..."
    return text


def build_line_table(code):
    """line_of[i] = line number (starting at 1) of the character at index i."""
    table = []
    line = 1
    for ch in code:
        table.append(line)
        if ch == "\n":
            line += 1
    return table


def find_closing_paren(text, open_index):
    """Return the index of the ')' that matches the '(' at open_index, or -1."""
    depth = 0
    for k in range(open_index, len(text)):
        if text[k] == "(":
            depth += 1
        elif text[k] == ")":
            depth -= 1
            if depth == 0:
                return k
    return -1


def ends_with_operator(text):
    """True if the text ends with an operator, e.g.  'x = 5 +'.
    'a++' and 'a--' are fine, so they are excluded."""
    if text.endswith("++") or text.endswith("--"):
        return False
    return text[-1] in OPERATOR_END


def is_assign_eq(text, k):
    """Is the '=' at position k a real assignment (not ==, !=, <=, >=)?"""
    if text[k] != "=":
        return False
    if k + 1 < len(text) and text[k + 1] == "=":
        return False                       # first '=' of '=='
    if k > 0:
        prev = text[k - 1]
        if prev in "=!":
            return False                   # '==' or '!='
        if prev in "<>":                   # '<=' / '>=' but '<<=' / '>>=' are ok
            return k >= 2 and text[k - 2] == prev
    return True


def find_assignment(text):
    """Return the index of the first assignment '=' outside brackets, or -1."""
    depth = 0
    for k, ch in enumerate(text):
        if ch in "([":
            depth += 1
        elif ch in ")]":
            depth = max(0, depth - 1)
        elif ch == "=" and depth == 0 and is_assign_eq(text, k):
            return k
    return -1


def is_header_only(text):
    """True for things like  'if (x)', 'else', 'do', 'else if (x)', 'while (x)'.
    These are allowed to end a line without a semicolon."""
    rest = re.sub(r"^else\b\s*", "", text)
    if rest == "" or rest == "do":
        return True
    m = re.match(r"^(if|while|for|switch)\s*\(", rest)
    if m:
        close = find_closing_paren(rest, m.end() - 1)
        return close == len(rest) - 1      # the ')' is the last character
    return False


def next_significant(clean, i):
    """Return the next non-space character after index i ('' at end of text)."""
    j = i + 1
    while j < len(clean) and clean[j].isspace():
        j += 1
    return clean[j] if j < len(clean) else ""


def skip_braces(clean, i):
    """clean[i] is '{'. Return the index just after its matching '}'."""
    depth = 0
    for j in range(i, len(clean)):
        if clean[j] == "{":
            depth += 1
        elif clean[j] == "}":
            depth -= 1
            if depth == 0:
                return j + 1
    return len(clean)


# ---------- STEP 1 : clean the source ----------

def clean_source(code, add):
    """Return a copy of the code of the SAME LENGTH in which comments,
    string contents and preprocessor lines are replaced by spaces.
    Newlines are kept, so line numbers never change."""
    out = list(code)
    n = len(code)
    i = 0
    line = 1
    line_has_code = False          # used to detect lines starting with '#'

    def blank(a, b):
        for k in range(a, b):
            if out[k] != "\n":
                out[k] = " "

    while i < n:
        c = code[i]
        nxt = code[i + 1] if i + 1 < n else ""

        if c == "\n":
            line += 1
            line_has_code = False
            i += 1

        elif c == "/" and nxt == "/":                      # // comment
            j = code.find("\n", i)
            j = n if j == -1 else j
            blank(i, j)
            i = j

        elif c == "/" and nxt == "*":                      # /* comment */
            j = code.find("*/", i + 2)
            if j == -1:
                add(line, "Error", "Unterminated comment: '/*' has no closing '*/'")
                j = n
            else:
                j += 2
            line += code.count("\n", i, j)
            blank(i, j)
            i = j

        elif c == '"' or c == "'":                         # string / char literal
            j = i + 1
            while j < n and code[j] != c and code[j] != "\n":
                if code[j] == "\\" and j + 1 < n and code[j + 1] != "\n":
                    j += 2
                else:
                    j += 1
            if j < n and code[j] == c:
                blank(i + 1, j)                            # keep quotes, blank inside
                i = j + 1
            else:
                what = "string" if c == '"' else "character"
                add(line, "Error", "Unterminated %s literal (missing closing %s)" % (what, c))
                blank(i + 1, min(j, n))
                i = j
            line_has_code = True

        elif c == "#" and not line_has_code:               # #include, #define ...
            j = code.find("\n", i)
            j = n if j == -1 else j
            blank(i, j)
            i = j

        else:
            if not c.isspace():
                line_has_code = True
            i += 1

    return "".join(out)


# ---------- STEP 2 : bracket matching with a stack ----------

def check_brackets(clean, line_of, add):
    closer_to_opener = {")": "(", "]": "[", "}": "{"}
    opener_to_closer = {"(": ")", "[": "]", "{": "}"}
    names = {"(": "parenthesis", "[": "square bracket", "{": "curly brace"}
    stack = []                                   # holds (bracket, line)

    for i, ch in enumerate(clean):
        if ch in opener_to_closer:
            stack.append((ch, line_of[i]))

        elif ch in closer_to_opener:
            need = closer_to_opener[ch]
            if stack and stack[-1][0] == need:   # perfect match
                stack.pop()
                continue

            # Is the matching opener somewhere deeper in the stack?
            pos = None
            for k in range(len(stack) - 1, -1, -1):
                if stack[k][0] == need:
                    pos = k
                    break

            if pos is None:                      # nothing to match with
                add(line_of[i], "Error",
                    "Unmatched closing %s '%s' (no matching '%s')" % (names[need], ch, need))
            else:                                # openers above it were never closed
                while len(stack) - 1 > pos:
                    o, l = stack.pop()
                    add(l, "Error", "Unmatched opening %s '%s' (missing '%s')"
                        % (names[o], o, opener_to_closer[o]))
                stack.pop()

    for o, l in stack:                           # still open at end of file
        add(l, "Error", "Unmatched opening %s '%s' (missing '%s')"
            % (names[o], o, opener_to_closer[o]))


# ---------- STEP 3 : statement checks ----------

def check_statement(t, shown, line_first, line_last, kind, add):
    """Check one statement.
    t     : cleaned statement text
    shown : original text used in messages
    kind  : 'semi'  -> ended with ';'
            'brace' -> ended with '{'  (a block header such as a function or if)
            'open'  -> ended WITHOUT ';' (new line, '}' or end of file)
    """
    if not t:
        return
    if not any(ch.isalnum() or ch == "_" for ch in t):
        return                                   # only stray symbols like ')' - already reported
    if kind == "open" and t.endswith(":"):       # case 1:  /  default:  /  label:
        return

    # ---- if / while / for / switch ----
    m = CONTROL_RE.match(t)
    if m:
        kw = m.group(2)
        rest = t[m.end():].lstrip()
        if not rest.startswith("("):
            add(line_first, "Error", "Missing '(' after '%s'" % kw)
            return
        close = find_closing_paren(rest, 0)
        if close == -1:
            return                               # bracket check reports this
        cond = rest[1:close].strip()
        body = rest[close + 1:].strip()

        if kw == "for":
            count = cond.count(";")
            if count != 2:
                add(line_first, "Error",
                    "Invalid 'for' header: expected two ';' inside ( ), found %d" % count)
        elif cond == "":
            add(line_first, "Error", "Missing condition in '%s' statement" % kw)
        elif find_assignment(cond) != -1:
            add(line_first, "Warning",
                "Assignment '=' used inside condition (did you mean '=='?)")

        if body:
            check_statement(body, shown, line_first, line_last, kind, add)
        elif kind == "open":
            if kw == "while":
                add(line_last, "Error",
                    "Incomplete statement: missing body or ';' after " + shown)
            else:
                add(line_last, "Error",
                    "Incomplete statement: missing body after " + shown)
        return

    # ---- else / do ----
    m = ELSE_DO_RE.match(t)
    if m:
        rest = t[m.end():].strip()
        if rest:
            check_statement(rest, shown, line_first, line_last, kind, add)
        elif kind == "open":
            add(line_last, "Error", "Incomplete statement: missing body after " + shown)
        return

    if kind == "brace":                          # function header, struct ... : fine
        return

    # ---- simple statement: declaration, assignment, call, return ... ----
    k = find_assignment(t)
    if k != -1:
        lhs = t[:k].rstrip().rstrip("+-*/%&|^<>").strip()   # drop += -= etc.
        rhs = t[k + 1:].strip()
        if rhs == "":
            add(line_last, "Error", "Missing expression in assignment: " + shown)
            return
        if lhs == "":
            add(line_first, "Error", "Missing left-hand side in assignment: " + shown)
            return

    if ends_with_operator(t) or t in TYPE_WORDS:
        add(line_last, "Error", "Incomplete statement: " + shown)
        return

    if kind == "open":
        add(line_last, "Error", "Missing semicolon after " + shown)


def run_check(code, clean, line_of, start, end, kind, add):
    """Cut the statement out of the text and send it to check_statement."""
    text = clean[start:end].strip()
    shown = shorten(code[start:end])
    check_statement(text, shown, line_of[start], line_of[end - 1], kind, add)


def should_flush(t, next_char):
    """At the end of a line: does a NEW statement start on the next line while
    the current one has no ';'?  If so, the semicolon is missing."""
    if not t or next_char == "":
        return False
    if not (next_char.isalnum() or next_char == "_"):
        return False                  # next line continues (operator, '{', '}' ...)
    if t[-1] in ";{}:":
        return False
    if ends_with_operator(t):
        return False                  # expression continues on the next line
    if is_header_only(t):
        return False                  # if (x)  /  else  /  while (x)  ...
    return True


def check_statements(code, clean, line_of, add):
    n = len(clean)
    start = None            # index where the current statement begins
    end = None              # index just after its last character
    paren = 0               # how many '(' are currently open
    prev_sig = ""           # previous non-space character
    i = 0

    while i < n:
        c = clean[i]

        # ----- whitespace -----
        if c.isspace():
            if c == "\n" and start is not None and paren == 0:
                nxt = next_significant(clean, i)
                if should_flush(clean[start:end].strip(), nxt):
                    run_check(code, clean, line_of, start, end, "open", add)
                    start = end = None
            i += 1
            continue

        # ----- ';' -----
        if c == ";":
            if paren > 0 and start is not None and FOR_RE.match(clean[start:end].strip()):
                end = i + 1                       # ';' inside  for ( ... )  is fine
            else:
                if start is None:
                    if prev_sig != "}":           # '};' after struct is normal
                        add(line_of[i], "Warning", "Empty statement (extra ';')")
                elif paren == 0:
                    run_check(code, clean, line_of, start, end, "semi", add)
                start = end = None
                paren = 0

        # ----- '{' -----
        elif c == "{":
            if start is not None and paren == 0 and clean[start:end].rstrip().endswith("="):
                j = skip_braces(clean, i)         # initializer:  int a[] = {1, 2};
                end = j
                i = j
                prev_sig = "}"
                continue
            if start is not None and paren == 0:
                run_check(code, clean, line_of, start, end, "brace", add)
            start = end = None
            paren = 0

        # ----- '}' -----
        elif c == "}":
            if start is not None and paren == 0:
                run_check(code, clean, line_of, start, end, "open", add)
            start = end = None
            paren = 0

        # ----- any other character -----
        else:
            if start is None:
                start = i
            end = i + 1
            if c == "(":
                paren += 1
            elif c == ")" and paren > 0:
                paren -= 1

        prev_sig = c
        i += 1

    if start is not None and paren == 0:          # text left at end of file
        run_check(code, clean, line_of, start, end, "open", add)


# ---------- main entry point of the analyzer ----------

def analyze_code(code):
    """Return a list of issues: (line_number, 'Error' or 'Warning', message)."""
    issues = []
    seen = set()

    def add(line, kind, message):
        key = (line, kind, message)
        if key not in seen:                       # never report the same thing twice
            seen.add(key)
            issues.append(key)

    if not isinstance(code, str):
        add(1, "Error", "Invalid input: source code must be text")
        return issues

    code = code.replace("\r\n", "\n").replace("\r", "\n").replace("\x00", " ")

    clean = clean_source(code, add)
    line_of = build_line_table(code)
    check_brackets(clean, line_of, add)
    check_statements(code, clean, line_of, add)

    issues.sort(key=lambda item: (item[0], 0 if item[1] == "Error" else 1))
    return issues


def build_report(issues):
    """Turn the issue list into (style, text) lines for display."""
    errors = [x for x in issues if x[1] == "Error"]
    warnings = [x for x in issues if x[1] == "Warning"]
    lines = []

    if errors:
        lines.append(("heading", "Syntax Error:" if len(errors) == 1 else "Syntax Errors:"))
        for line, _, msg in errors:
            lines.append(("error", "Line %d: %s" % (line, msg)))
    else:
        lines.append(("success", "Success: No syntax errors detected."))
        lines.append(("plain", "(Only the supported checks were performed.)"))
    lines.append(("plain", ""))

    if warnings:
        lines.append(("heading", "Warning:" if len(warnings) == 1 else "Warnings:"))
        for line, _, msg in warnings:
            lines.append(("warning", "Line %d: %s" % (line, msg)))
        lines.append(("plain", ""))

    lines.append(("plain", "Analysis completed."))
    return lines


# ---------- TOKENIZER (lexical analysis) ----------

C_KEYWORDS = {"auto", "break", "case", "char", "const", "continue", "default",
              "do", "double", "else", "enum", "extern", "float", "for", "goto",
              "if", "int", "long", "register", "return", "short", "signed",
              "sizeof", "static", "struct", "switch", "typedef", "union",
              "unsigned", "void", "volatile", "while"}

# One big pattern. Each named group is one kind of token.
# Comments and white space are matched too, but they are skipped (not shown).
TOKEN_RE = re.compile(r"""
    (?P<COMMENT>   //[^\n]* | /\*.*?(?:\*/|\Z) )
  | (?P<PREPROCESSOR> ^[ \t]*\#[^\n]* )
  | (?P<STRING>    "(?:\\.|[^"\\\n])*" )
  | (?P<CHARACTER> '(?:\\.|[^'\\\n])*' )
  | (?P<NUMBER>    0[xX][0-9a-fA-F]+ | \d+\.\d*(?:[eE][+-]?\d+)? | \.\d+ | \d+ )
  | (?P<IDENTIFIER> [A-Za-z_]\w* )
  | (?P<OPERATOR>  <<= | >>= | \+\+ | -- | -> | << | >> | <= | >= | == | !=
                   | && | \|\| | \+= | -= | \*= | /= | %= | &= | \|= | \^=
                   | [-+*/%=<>!&|^~?:.] )
  | (?P<SEPARATOR> [(){}\[\];,] )
  | (?P<SPACE>     \s+ )
  | (?P<UNKNOWN>   . )
""", re.VERBOSE | re.DOTALL | re.MULTILINE)


def tokenize(code):
    """Split the code into tokens.
    Returns a list of (line_number, token_type, lexeme)."""
    if not isinstance(code, str):
        return []
    code = code.replace("\r\n", "\n").replace("\r", "\n").replace("\x00", " ")
    line_of = build_line_table(code)
    tokens = []
    for m in TOKEN_RE.finditer(code):
        kind = m.lastgroup
        if kind in ("COMMENT", "SPACE"):
            continue                                  # not tokens
        text = m.group()
        if kind == "PREPROCESSOR":
            text = text.strip()
            line = line_of[m.start() + m.group().index("#")]
        else:
            line = line_of[m.start()]
        if kind == "IDENTIFIER" and text in C_KEYWORDS:
            kind = "KEYWORD"
        tokens.append((line, kind, text))
    return tokens


# =====================================================================
#  PART 2 : TKINTER GUI
# =====================================================================

class SyntaxAnalyzerApp:
    def __init__(self, root):
        self.root = root
        root.title("Syntax Analyzer and Error Detector")
        root.geometry("1100x720")
        root.minsize(800, 500)

        mono = ("Courier New", 11)

        tk.Label(root, text="Enter simple C code:",
                 font=("Arial", 11, "bold")).pack(anchor="w", padx=10, pady=(10, 2))

        self.code_box = scrolledtext.ScrolledText(root, height=14, font=mono, undo=True)
        self.code_box.pack(fill="both", expand=True, padx=10)

        buttons = tk.Frame(root)
        buttons.pack(pady=8)
        tk.Button(buttons, text="Analyze Code", width=16,
                  command=self.analyze).pack(side="left", padx=5)
        tk.Button(buttons, text="Clear", width=16,
                  command=self.clear).pack(side="left", padx=5)

        # bottom area: results on the left, tokens on the right
        bottom = tk.Frame(root)
        bottom.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        left = tk.Frame(bottom)
        left.pack(side="left", fill="both", expand=True)
        right = tk.Frame(bottom)
        right.pack(side="left", fill="both", expand=True, padx=(10, 0))

        # --- analysis results (syntax errors / warnings) ---
        tk.Label(left, text="Analysis results:",
                 font=("Arial", 11, "bold")).pack(anchor="w", pady=(0, 2))
        self.output_box = scrolledtext.ScrolledText(left, height=10, width=40, font=mono,
                                                    state="disabled", bg="#f4f4f4")
        self.output_box.pack(fill="both", expand=True)

        self.output_box.tag_config("heading", font=("Courier New", 11, "bold"))
        self.output_box.tag_config("error", foreground="#b00020")
        self.output_box.tag_config("warning", foreground="#b26a00")
        self.output_box.tag_config("success", foreground="#1b7a2b",
                                   font=("Courier New", 11, "bold"))

        # --- token table (lexical analysis) ---
        self.token_label = tk.Label(right, text="Tokens (lexical analysis):",
                                    font=("Arial", 11, "bold"))
        self.token_label.pack(anchor="w", pady=(0, 2))
        table = tk.Frame(right)
        table.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(table, columns=("line", "type", "lexeme"),
                                 show="headings", height=10)
        self.tree.heading("line", text="Line")
        self.tree.heading("type", text="Token Type")
        self.tree.heading("lexeme", text="Token")
        self.tree.column("line", width=50, anchor="center", stretch=False)
        self.tree.column("type", width=120, stretch=False)
        self.tree.column("lexeme", width=200)
        scroll = ttk.Scrollbar(table, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

    def show(self, lines):
        """Write (style, text) lines into the read-only output area."""
        self.output_box.config(state="normal")
        self.output_box.delete("1.0", "end")
        for style, text in lines:
            self.output_box.insert("end", text + "\n", style)
        self.output_box.config(state="disabled")

    def show_tokens(self, tokens):
        """Fill the token table."""
        self.tree.delete(*self.tree.get_children())
        for line, kind, lexeme in tokens:
            self.tree.insert("", "end", values=(line, kind, lexeme))
        self.token_label.config(text="Tokens (lexical analysis): %d found" % len(tokens))

    def analyze(self):
        try:
            code = self.code_box.get("1.0", "end-1c")
            if not code.strip():
                self.show([("warning", "Please enter some C code before analyzing."),
                           ("plain", ""), ("plain", "Analysis completed.")])
                self.show_tokens([])
                return
            self.show_tokens(tokenize(code))
            self.show(build_report(analyze_code(code)))
        except Exception as exc:                  # never crash the window
            self.show([("error", "Internal error: could not analyze this input."),
                       ("error", str(exc))])

    def clear(self):
        self.code_box.delete("1.0", "end")
        self.show([])
        self.show_tokens([])
        self.token_label.config(text="Tokens (lexical analysis):")
        self.code_box.focus_set()


def main():
    root = tk.Tk()
    SyntaxAnalyzerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
